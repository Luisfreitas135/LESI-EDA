#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINHAS 20
#define MAX_COLUNAS 20

/**
 * @file antenas.h
 * @brief Header file para manipulação de antenas e efeitos nefastos.
 *
 * Este ficheiro contém as declarações de estruturas e funções
 * para gerir antenas e calcular os efeitos nefastos associados.
 */

/**
 * @brief Estrutura para representar uma antena.
 */
typedef struct Antena {
    char frequencia;  ///< Frequência da antena.
    int x, y;         ///< Coordenadas da antena.
    struct Antena *prox; ///< Apontador para a próxima antena na lista.
} Antena;

/**
 * @brief Estrutura para representar um efeito nefasto.
 */
typedef struct EfeitoNefasto {
    int x, y;         ///< Coordenadas do efeito nefasto.
    struct EfeitoNefasto *prox; ///< Apontador para o próximo efeito nefasto na lista.
} EfeitoNefasto;

/**
 * @brief Cria uma nova antena.
 * @param freq Frequência da antena.
 * @param x Coordenada x da antena.
 * @param y Coordenada y da antena.
 * @return Apontador para a nova antena, ou NULL em caso de falha na alocação.
 */
Antena* criarAntena(char freq, int x, int y);

/**
 * @brief Insere uma antena na lista ligada.
 * @param lista Apontador para o início da lista de antenas.
 * @param freq Frequência da antena a inserir.
 * @param x Coordenada x da antena a inserir.
 * @param y Coordenada y da antena a inserir.
 */
void inserirAntena(Antena **lista, char freq, int x, int y);

/**
 * @brief Remove uma antena da lista ligada.
 * @param lista Apontador para o início da lista de antenas.
 * @param x Coordenada x da antena a remover.
 * @param y Coordenada y da antena a remover.
 */
void removerAntena(Antena **lista, int x, int y);

/**
 * @brief Adiciona um efeito nefasto à lista.
 * @param lista Apontador para o início da lista de efeitos nefastos.
 * @param x Coordenada x do efeito nefasto a adicionar.
 * @param y Coordenada y do efeito nefasto a adicionar.
 */
void adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y);

/**
 * @brief Verifica se um efeito nefasto já existe na lista.
 * @param lista Apontador para o início da lista de efeitos nefastos.
 * @param x Coordenada x do efeito a verificar.
 * @param y Coordenada y do efeito a verificar.
 * @return 1 se o efeito existe, 0 caso contrário.
 */
int efeitoExiste(EfeitoNefasto *lista, int x, int y);

/**
 * @brief Calcula os efeitos nefastos com base na posição das antenas.
 * @param lista Apontador para o início da lista de antenas.
 * @param efeitos Apontador para o início da lista de efeitos nefastos.
 */
void calcularEfeitosNefastos(Antena *lista, EfeitoNefasto **efeitos);

/**
 * @brief Carrega as antenas de um ficheiro.
 * @param nomeFicheiro Nome do ficheiro a carregar.
 * @param linhas Apontador para o número de linhas lidas do ficheiro.
 * @param colunas Apontador para o número de colunas lidas do ficheiro.
 * @return Apontador para a lista de antenas carregadas, ou NULL em caso de erro.
 */
Antena* carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas);

/**
 * @brief Lista as antenas na consola.
 * @param lista Apontador para o início da lista de antenas.
 */
void listarAntenas(Antena *lista);

/**
 * @brief Lista os locais com efeito nefasto na consola.
 * @param lista Apontador para o início da lista de efeitos nefastos.
 */
void listarEfeitosNefastos(EfeitoNefasto *lista);