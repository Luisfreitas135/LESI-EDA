/**
 * @file antenas.c
 * @brief Implementação das funções para manipulação de antenas e efeitos nefastos.
 *
 * Este ficheiro contém a implementação das funções declaradas em antenas.h.
 */

 #include "antenas.h"
 #include <math.h>
 
 /**
  * @brief Cria uma nova antena.
  * @param freq Frequência da antena.
  * @param x Coordenada x da antena.
  * @param y Coordenada y da antena.
  * @return Apontador para a nova antena, ou NULL em caso de falha na alocação.
  */
 Antena* criarAntena(char freq, int x, int y) {
     Antena *nova = (Antena*)malloc(sizeof(Antena));
     if (!nova) return NULL;
     nova->frequencia = freq;
     nova->x = x;
     nova->y = y;
     nova->prox = NULL;
     return nova;
 }
 
 /**
  * @brief Insere uma antena na lista ligada.
  * @param lista Apontador para o início da lista de antenas.
  * @param freq Frequência da antena a inserir.
  * @param x Coordenada x da antena a inserir.
  * @param y Coordenada y da antena a inserir.
  */
 void inserirAntena(Antena **lista, char freq, int x, int y) {
     Antena *nova = criarAntena(freq, x, y);
     if (!nova) return;
     nova->prox = *lista;
     *lista = nova;
 }
 
 /**
  * @brief Remove uma antena da lista ligada.
  * @param lista Apontador para o início da lista de antenas.
  * @param x Coordenada x da antena a remover.
  * @param y Coordenada y da antena a remover.
  */
 void removerAntena(Antena **lista, int x, int y) {
     Antena *atual = *lista, *anterior = NULL;
     while (atual) {
         if (atual->x == x && atual->y == y) {
             if (anterior)
                 anterior->prox = atual->prox;
             else
                 *lista = atual->prox;
             free(atual);
             return;
         }
         anterior = atual;
         atual = atual->prox;
     }
 }
 
 /**
  * @brief Adiciona um efeito nefasto à lista.
  * @param lista Apontador para o início da lista de efeitos nefastos.
  * @param x Coordenada x do efeito nefasto a adicionar.
  * @param y Coordenada y do efeito nefasto a adicionar.
  */
 void adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y) {
     EfeitoNefasto *novo = (EfeitoNefasto*)malloc(sizeof(EfeitoNefasto));
     if (!novo) return;
     novo->x = x;
     novo->y = y;
     novo->prox = *lista;
     *lista = novo;
 }
 
 /**
  * @brief Verifica se um efeito nefasto já existe na lista.
  * @param lista Apontador para o início da lista de efeitos nefastos.
  * @param x Coordenada x do efeito a verificar.
  * @param y Coordenada y do efeito a verificar.
  * @return 1 se o efeito existe, 0 caso contrário.
  */
 int efeitoExiste(EfeitoNefasto *lista, int x, int y) {
     while (lista) {
         if (lista->x == x && lista->y == y)
             return 1;
         lista = lista->prox;
     }
     return 0;
 }
 
 /**
  * @brief Calcula os efeitos nefastos com base na posição das antenas.
  * @param lista Apontador para o início da lista de antenas.
  * @param efeitos Apontador para o início da lista de efeitos nefastos.
  */
 void calcularEfeitosNefastos(Antena *lista, EfeitoNefasto **efeitos) {
     Antena *a1, *a2;
     for (a1 = lista; a1 != NULL; a1 = a1->prox) {
         for (a2 = lista; a2 != NULL; a2 = a2->prox) {
             if (a1 != a2 && a1->frequencia == a2->frequencia) {
                 int dx = a2->x - a1->x;
                 int dy = a2->y - a1->y;
                 // Verifica se a distância entre as antenas é válida para calcular o efeito nefasto
                 if (dx != 0 && dy != 0 && abs(dx) == 2 * abs(dy)) {
                     int nx1 = a1->x - dx / 2;
                     int ny1 = a1->y - dy / 2;
                     int nx2 = a2->x + dx / 2;
                     int ny2 = a2->y + dy / 2;
                     if (!efeitoExiste(*efeitos, nx1, ny1))
                         adicionarEfeitoNefasto(efeitos, nx1, ny1);
                     if (!efeitoExiste(*efeitos, nx2, ny2))
                         adicionarEfeitoNefasto(efeitos, nx2, ny2);
                 }
             }
         }
     }
 }
 
 /**
  * @brief Carrega as antenas de um ficheiro.
  * @param nomeFicheiro Nome do ficheiro a carregar.
  * @param linhas Apontador para o número de linhas lidas do ficheiro.
  * @param colunas Apontador para o número de colunas lidas do ficheiro.
  * @return Apontador para a lista de antenas carregadas, ou NULL em caso de erro.
  */
 Antena* carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas) {
     FILE *file = fopen(nomeFicheiro, "r");
     if (!file) return NULL;
     Antena *lista = NULL;
     char linha[MAX_COLUNAS];
     int y = 0;
     while (fgets(linha, sizeof(linha), file)) {
         *colunas = strlen(linha) - 1;
         for (int x = 0; x < *colunas; x++) {
             if (linha[x] != '.' && linha[x] != '\n') {
                 inserirAntena(&lista, linha[x], x, y);
             }
         }
         y++;
     }
     *linhas = y;
     fclose(file);
     return lista;
 }
 
 /**
  * @brief Lista as antenas na consola.
  * @param lista Apontador para o início da lista de antenas.
  */
 void listarAntenas(Antena *lista) {
     printf("Lista de antenas:\n");
     while (lista) {
         printf("Antena %c em (%d, %d)\n", lista->frequencia, lista->x, lista->y);
         lista = lista->prox;
     }
 }
 
 /**
  * @brief Lista os locais com efeito nefasto na consola.
  * @param lista Apontador para o início da lista de efeitos nefastos.
  */
 void listarEfeitosNefastos(EfeitoNefasto *lista) {
     printf("\nLocais com efeito nefasto:\n");
     while (lista) {
         printf("Efeito nefasto em (%d, %d)\n", lista->x, lista->y);
         lista = lista->prox;
     }
 }