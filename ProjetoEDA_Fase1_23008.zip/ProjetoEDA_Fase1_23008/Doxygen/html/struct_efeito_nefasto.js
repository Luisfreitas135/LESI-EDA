var struct_efeito_nefasto =
[
    [ "prox", "struct_efeito_nefasto.html#a53e7fb8649bf869983a43dcf0821a88a", null ],
    [ "y", "struct_efeito_nefasto.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];