var antenas_8h =
[
    [ "Antena", "struct_antena.html", "struct_antena" ],
    [ "EfeitoNefasto", "struct_efeito_nefasto.html", "struct_efeito_nefasto" ],
    [ "Antena", "antenas_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2", null ],
    [ "EfeitoNefasto", "antenas_8h.html#a6167db7f1ec0c34503d24b77b3613bfa", null ],
    [ "adicionarEfeitoNefasto", "antenas_8h.html#a8597df31deda080bce35c2c17525817b", null ],
    [ "calcularEfeitosNefastos", "antenas_8h.html#ac7d27b0db089512be9656a8743b2038e", null ],
    [ "carregarDeFicheiro", "antenas_8h.html#aed3d11bfbbaa3b0c5a92eee7ec8e13fc", null ],
    [ "criarAntena", "antenas_8h.html#a45d602813bfa39b2875ba12549e962c5", null ],
    [ "efeitoExiste", "antenas_8h.html#ad7909d4b24e8a2eff85a180949ade2b9", null ],
    [ "inserirAntena", "antenas_8h.html#a793b4cddf2584e44f87c9fcc2cdb9c13", null ],
    [ "listarAntenas", "antenas_8h.html#ad8e25ea7e05f77d363c12d6f63e7ebde", null ],
    [ "listarEfeitosNefastos", "antenas_8h.html#a170a592bef219afa7b3bcbb623265e00", null ],
    [ "removerAntena", "antenas_8h.html#a3d850166e6200fb0c07c884577660bc0", null ]
];