var files_dup =
[
    [ "antenas.c", "antenas_8c.html", "antenas_8c" ],
    [ "antenas.h", "antenas_8h.html", "antenas_8h" ]
];