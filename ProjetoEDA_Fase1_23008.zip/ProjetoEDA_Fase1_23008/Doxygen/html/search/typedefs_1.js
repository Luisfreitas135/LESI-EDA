var searchData=
[
  ['efeitonefasto_0',['EfeitoNefasto',['../antenas_8h.html#a6167db7f1ec0c34503d24b77b3613bfa',1,'antenas.h']]]
];
