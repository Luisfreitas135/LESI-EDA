var searchData=
[
  ['removerantena_0',['removerAntena',['../antenas_8c.html#a3d850166e6200fb0c07c884577660bc0',1,'removerAntena(Antena **lista, int x, int y):&#160;antenas.c'],['../antenas_8h.html#a3d850166e6200fb0c07c884577660bc0',1,'removerAntena(Antena **lista, int x, int y):&#160;antenas.c']]]
];
