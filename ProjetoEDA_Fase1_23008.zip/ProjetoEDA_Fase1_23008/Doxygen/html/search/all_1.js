var searchData=
[
  ['calcularefeitosnefastos_0',['calcularEfeitosNefastos',['../antenas_8c.html#ac7d27b0db089512be9656a8743b2038e',1,'calcularEfeitosNefastos(Antena *lista, EfeitoNefasto **efeitos):&#160;antenas.c'],['../antenas_8h.html#ac7d27b0db089512be9656a8743b2038e',1,'calcularEfeitosNefastos(Antena *lista, EfeitoNefasto **efeitos):&#160;antenas.c']]],
  ['carregardeficheiro_1',['carregarDeFicheiro',['../antenas_8c.html#aed3d11bfbbaa3b0c5a92eee7ec8e13fc',1,'carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas):&#160;antenas.c'],['../antenas_8h.html#aed3d11bfbbaa3b0c5a92eee7ec8e13fc',1,'carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas):&#160;antenas.c']]],
  ['criarantena_2',['criarAntena',['../antenas_8c.html#a45d602813bfa39b2875ba12549e962c5',1,'criarAntena(char freq, int x, int y):&#160;antenas.c'],['../antenas_8h.html#a45d602813bfa39b2875ba12549e962c5',1,'criarAntena(char freq, int x, int y):&#160;antenas.c']]]
];
