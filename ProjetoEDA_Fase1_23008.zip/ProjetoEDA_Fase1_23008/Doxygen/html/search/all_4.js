var searchData=
[
  ['inserirantena_0',['inserirAntena',['../antenas_8c.html#a793b4cddf2584e44f87c9fcc2cdb9c13',1,'inserirAntena(Antena **lista, char freq, int x, int y):&#160;antenas.c'],['../antenas_8h.html#a793b4cddf2584e44f87c9fcc2cdb9c13',1,'inserirAntena(Antena **lista, char freq, int x, int y):&#160;antenas.c']]]
];
