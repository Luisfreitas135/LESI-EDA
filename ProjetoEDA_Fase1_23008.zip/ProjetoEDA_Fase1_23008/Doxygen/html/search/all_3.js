var searchData=
[
  ['frequencia_0',['frequencia',['../struct_antena.html#a643fe33fe56ce4c44a24d28a121d5d23',1,'Antena']]]
];
