var searchData=
[
  ['listarantenas_0',['listarAntenas',['../antenas_8c.html#ad8e25ea7e05f77d363c12d6f63e7ebde',1,'listarAntenas(Antena *lista):&#160;antenas.c'],['../antenas_8h.html#ad8e25ea7e05f77d363c12d6f63e7ebde',1,'listarAntenas(Antena *lista):&#160;antenas.c']]],
  ['listarefeitosnefastos_1',['listarEfeitosNefastos',['../antenas_8c.html#a170a592bef219afa7b3bcbb623265e00',1,'listarEfeitosNefastos(EfeitoNefasto *lista):&#160;antenas.c'],['../antenas_8h.html#a170a592bef219afa7b3bcbb623265e00',1,'listarEfeitosNefastos(EfeitoNefasto *lista):&#160;antenas.c']]]
];
