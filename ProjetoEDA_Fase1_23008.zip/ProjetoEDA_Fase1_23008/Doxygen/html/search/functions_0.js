var searchData=
[
  ['adicionarefeitonefasto_0',['adicionarEfeitoNefasto',['../antenas_8c.html#a8597df31deda080bce35c2c17525817b',1,'adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y):&#160;antenas.c'],['../antenas_8h.html#a8597df31deda080bce35c2c17525817b',1,'adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y):&#160;antenas.c']]]
];
