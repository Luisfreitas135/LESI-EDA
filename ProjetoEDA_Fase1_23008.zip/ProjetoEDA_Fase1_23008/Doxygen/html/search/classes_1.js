var searchData=
[
  ['efeitonefasto_0',['EfeitoNefasto',['../struct_efeito_nefasto.html',1,'']]]
];
