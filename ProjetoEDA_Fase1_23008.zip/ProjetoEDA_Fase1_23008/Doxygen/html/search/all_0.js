var searchData=
[
  ['adicionarefeitonefasto_0',['adicionarEfeitoNefasto',['../antenas_8c.html#a8597df31deda080bce35c2c17525817b',1,'adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y):&#160;antenas.c'],['../antenas_8h.html#a8597df31deda080bce35c2c17525817b',1,'adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y):&#160;antenas.c']]],
  ['antena_1',['Antena',['../struct_antena.html',1,'Antena'],['../antenas_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2',1,'Antena:&#160;antenas.h']]],
  ['antenas_2ec_2',['antenas.c',['../antenas_8c.html',1,'']]],
  ['antenas_2eh_3',['antenas.h',['../antenas_8h.html',1,'']]]
];
