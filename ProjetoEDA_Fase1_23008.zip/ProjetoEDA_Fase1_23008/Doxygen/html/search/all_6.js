var searchData=
[
  ['prox_0',['prox',['../struct_antena.html#a43eb7a3a19eb2732361120c556e00e2d',1,'Antena::prox'],['../struct_efeito_nefasto.html#a53e7fb8649bf869983a43dcf0821a88a',1,'EfeitoNefasto::prox']]]
];
