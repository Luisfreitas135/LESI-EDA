var annotated_dup =
[
    [ "Antena", "struct_antena.html", "struct_antena" ],
    [ "EfeitoNefasto", "struct_efeito_nefasto.html", "struct_efeito_nefasto" ]
];