var struct_antena =
[
    [ "frequencia", "struct_antena.html#a643fe33fe56ce4c44a24d28a121d5d23", null ],
    [ "prox", "struct_antena.html#a43eb7a3a19eb2732361120c556e00e2d", null ],
    [ "y", "struct_antena.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];