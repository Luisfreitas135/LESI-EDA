var antenas_8c =
[
    [ "adicionarEfeitoNefasto", "antenas_8c.html#a8597df31deda080bce35c2c17525817b", null ],
    [ "calcularEfeitosNefastos", "antenas_8c.html#ac7d27b0db089512be9656a8743b2038e", null ],
    [ "carregarDeFicheiro", "antenas_8c.html#aed3d11bfbbaa3b0c5a92eee7ec8e13fc", null ],
    [ "criarAntena", "antenas_8c.html#a45d602813bfa39b2875ba12549e962c5", null ],
    [ "efeitoExiste", "antenas_8c.html#ad7909d4b24e8a2eff85a180949ade2b9", null ],
    [ "inserirAntena", "antenas_8c.html#a793b4cddf2584e44f87c9fcc2cdb9c13", null ],
    [ "listarAntenas", "antenas_8c.html#ad8e25ea7e05f77d363c12d6f63e7ebde", null ],
    [ "listarEfeitosNefastos", "antenas_8c.html#a170a592bef219afa7b3bcbb623265e00", null ],
    [ "removerAntena", "antenas_8c.html#a3d850166e6200fb0c07c884577660bc0", null ]
];