/**
 * @file main.c
 * @brief Ficheiro principal para testar funcionalidades da Fase 1 (Listas Ligadas).
 */

#include "antenas.h"

/**
 * @brief Função principal.
 * Carrega antenas de ficheiro, calcula efeitos nefastos e imprime os resultados.
 */
int main() {
    Antena *antenas = NULL;
    EfeitoNefasto *efeitos = NULL;
    int linhas = 0, colunas = 0;

    antenas = carregarDeFicheiro("antenas.txt", &linhas, &colunas);
    listarAntenas(antenas);
    calcularEfeitosNefastos(antenas, &efeitos);
    listarEfeitosNefastos(efeitos);

    return 0;
}
