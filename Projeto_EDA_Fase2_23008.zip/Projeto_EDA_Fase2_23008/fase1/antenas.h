/**
 * @file antenas.h
 * @brief Definições de estruturas e funções para manipulação de antenas e efeitos nefastos.
 */

#ifndef ANTENAS_H
#define ANTENAS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_LINHAS 100
#define MAX_COLUNAS 100

/**
 * @brief Estrutura que representa uma antena com frequência e coordenadas.
 */
typedef struct Antena {
    char frequencia;
    int x, y;
    struct Antena *prox;
} Antena;

/**
 * @brief Estrutura que representa um ponto com efeito nefasto.
 */
typedef struct EfeitoNefasto {
    int x, y;
    struct EfeitoNefasto *prox;
} EfeitoNefasto;

Antena* criarAntena(char freq, int x, int y);
void inserirAntena(Antena **lista, char freq, int x, int y);
void removerAntena(Antena **lista, int x, int y);
void adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y);
int efeitoExiste(EfeitoNefasto *lista, int x, int y);
void calcularEfeitosNefastos(Antena *lista, EfeitoNefasto **efeitos);
Antena* carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas);
void listarAntenas(Antena *lista);
void listarEfeitosNefastos(EfeitoNefasto *lista);

#endif
