/**
 * @file antenas.c
 * @brief Implementação das funções para manipulação de antenas e efeitos nefastos.
 */

#include "antenas.h"

/**
 * @brief Cria uma nova antena.
 */
Antena* criarAntena(char freq, int x, int y) {
    Antena *nova = (Antena*)malloc(sizeof(Antena));
    if (!nova) return NULL;
    nova->frequencia = freq;
    nova->x = x;
    nova->y = y;
    nova->prox = NULL;
    return nova;
}

/**
 * @brief Insere uma antena no início da lista ligada.
 */
void inserirAntena(Antena **lista, char freq, int x, int y) {
    Antena *nova = criarAntena(freq, x, y);
    if (!nova) return;
    nova->prox = *lista;
    *lista = nova;
}

/**
 * @brief Remove uma antena da lista ligada pelas suas coordenadas.
 */
void removerAntena(Antena **lista, int x, int y) {
    Antena *atual = *lista, *anterior = NULL;
    while (atual) {
        if (atual->x == x && atual->y == y) {
            if (anterior)
                anterior->prox = atual->prox;
            else
                *lista = atual->prox;
            free(atual);
            return;
        }
        anterior = atual;
        atual = atual->prox;
    }
}

/**
 * @brief Adiciona um efeito nefasto à lista (caso não exista).
 */
void adicionarEfeitoNefasto(EfeitoNefasto **lista, int x, int y) {
    if (efeitoExiste(*lista, x, y)) return;
    EfeitoNefasto *novo = (EfeitoNefasto*)malloc(sizeof(EfeitoNefasto));
    if (!novo) return;
    novo->x = x;
    novo->y = y;
    novo->prox = *lista;
    *lista = novo;
}

/**
 * @brief Verifica se um ponto já existe na lista de efeitos nefastos.
 */
int efeitoExiste(EfeitoNefasto *lista, int x, int y) {
    while (lista) {
        if (lista->x == x && lista->y == y)
            return 1;
        lista = lista->prox;
    }
    return 0;
}

/**
 * @brief Calcula os efeitos nefastos para todas as combinações de antenas com a mesma frequência.
 * Um efeito nefasto ocorre quando duas antenas estão alinhadas e uma está ao dobro da distância da outra.
 * Neste caso, dois pontos com efeito nefasto são gerados — um de cada lado das antenas.
 */
void calcularEfeitosNefastos(Antena *lista, EfeitoNefasto **efeitos) {
    for (Antena *a1 = lista; a1 != NULL; a1 = a1->prox) {
        for (Antena *a2 = lista; a2 != NULL; a2 = a2->prox) {
            if (a1 != a2 && a1->frequencia == a2->frequencia) {
                int dx = a2->x - a1->x;
                int dy = a2->y - a1->y;

                // Verifica se estão alinhadas (linha, coluna ou diagonal)
                if ((dx == 0 || dy == 0 || abs(dx) == abs(dy))) {
                    // Verifica se a2 está ao dobro da distância de a1 (ou vice-versa)
                    if ((dx % 2 == 0) && (dy % 2 == 0)) {
                        int mx = (a1->x + a2->x) / 2;
                        int my = (a1->y + a2->y) / 2;

                        // Calcula o vetor de deslocamento do ponto médio para gerar efeitos nefastos
                        int ex = mx - dx / 2;
                        int ey = my - dy / 2;
                        int ex2 = mx + dx / 2;
                        int ey2 = my + dy / 2;

                        // Adiciona os dois pontos espelhados
                        if (!efeitoExiste(*efeitos, ex, ey))
                            adicionarEfeitoNefasto(efeitos, ex, ey);
                        if (!efeitoExiste(*efeitos, ex2, ey2))
                            adicionarEfeitoNefasto(efeitos, ex2, ey2);
                    }
                }
            }
        }
    }
}


/**
 * @brief Lê o ficheiro e carrega as antenas para a lista ligada.
 */
Antena* carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas) {
    FILE *file = fopen(nomeFicheiro, "r");
    if (!file) return NULL;
    Antena *lista = NULL;
    char linha[MAX_COLUNAS];
    int y = 0;
    while (fgets(linha, sizeof(linha), file)) {
        linha[strcspn(linha, "\n")] = 0;
        *colunas = strlen(linha);
        for (int x = 0; x < *colunas; x++) {
            if (linha[x] != '.') {
                inserirAntena(&lista, linha[x], x, y);
            }
        }
        y++;
    }
    *linhas = y;
    fclose(file);
    return lista;
}

/**
 * @brief Lista todas as antenas no terminal.
 */
void listarAntenas(Antena *lista) {
    printf("Antenas:\n");
    while (lista) {
        printf("Frequência %c em (%d, %d)\n", lista->frequencia, lista->x, lista->y);
        lista = lista->prox;
    }
}

/**
 * @brief Lista os locais com efeitos nefastos.
 */
void listarEfeitosNefastos(EfeitoNefasto *lista) {
    printf("\nEfeitos Nefastos:\n");
    while (lista) {
        printf("Em (%d, %d)\n", lista->x, lista->y);
        lista = lista->prox;
    }
}
