#include "grafo.h"

/**
 * @file main.c
 * @brief Programa principal da Fase 2 com DFS e interseções corrigidas.
 */
int main() {
    Grafo *g = criarGrafo();

    if (construirGrafoDeFicheiro(g, "antenas.txt")) {
        listarVertices(g);
        guardarGrafoBinario(g, "grafo.bin");
    }

    Grafo *g2 = criarGrafo();
    if (carregarGrafoBinario(g2, "grafo.bin")) {
        conectarVerticesMesmaFrequencia(g2);
        printf("\nGrafo recarregado de binário:\n");
        listarVertices(g2);

        // Início DFS: procurar vértice 'A'
        Vertice *inicio = g2->vertices;
        while (inicio && inicio->frequencia != 'A')
            inicio = inicio->prox;

        if (inicio) {
            printf("\nDFS a partir de (%d,%d):\n", inicio->x, inicio->y);
            dfs(inicio);
        } else {
            printf("Nenhuma antena A encontrada para DFS.\n");
        }

        // Forçar interseção A e 0
        adicionarVertice(g2, 'A', 6, 6);
        adicionarVertice(g2, '0', 6, 6);

        intersecoesFrequencias(g2, 'A', '0');
    }

    return 0;
}
