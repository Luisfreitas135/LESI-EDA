var searchData=
[
  ['vertice_0',['Vertice',['../struct_vertice.html',1,'']]]
];
