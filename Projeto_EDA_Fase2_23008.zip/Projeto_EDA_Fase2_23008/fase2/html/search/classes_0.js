var searchData=
[
  ['aresta_0',['Aresta',['../struct_aresta.html',1,'']]]
];
