var searchData=
[
  ['intersecoesfrequencias_0',['intersecoesFrequencias',['../grafo_8h.html#a10317c4070a4992c62a0ab1ad06c80ca',1,'grafo.c']]]
];
