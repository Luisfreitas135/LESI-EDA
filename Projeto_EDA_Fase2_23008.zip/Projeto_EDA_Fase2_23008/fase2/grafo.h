/**
 * @file grafo.h
 * @brief Estruturas e funções para manipulação de grafos de antenas.
 */

#ifndef GRAFO_H
#define GRAFO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * @brief Estrutura de uma aresta.
 */
typedef struct Aresta {
    struct Vertice *destino;
    struct Aresta *prox;
} Aresta;

/**
 * @brief Estrutura de um vértice (antena).
 */
typedef struct Vertice {
    char frequencia;
    int x, y;
    struct Aresta *arestas;
    struct Vertice *prox;
} Vertice;

/**
 * @brief Estrutura do grafo.
 */
typedef struct {
    Vertice *vertices;
} Grafo;

// Funções principais
Grafo* criarGrafo();
Vertice* adicionarVertice(Grafo *g, char freq, int x, int y);
void adicionarAresta(Vertice *v1, Vertice *v2);
int construirGrafoDeFicheiro(Grafo *g, const char *nomeFicheiro);
int guardarGrafoBinario(Grafo *g, const char *ficheiro);
int carregarGrafoBinario(Grafo *g, const char *ficheiro);
void conectarVerticesMesmaFrequencia(Grafo *g);

// Operações obrigatórias
void listarVertices(Grafo *g);
void dfs(Vertice *inicio);
void caminhosEntre(Vertice *inicio, Vertice *fim);
void intersecoesFrequencias(Grafo *g, char f1, char f2);

#endif
