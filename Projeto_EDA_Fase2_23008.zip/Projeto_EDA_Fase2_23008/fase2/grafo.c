#include "grafo.h"

/**
 * @brief Cria e inicializa um grafo vazio.
 * @return Ponteiro para a estrutura Grafo criada.
 */
Grafo* criarGrafo() {
    Grafo *g = malloc(sizeof(Grafo));
    g->vertices = NULL;
    return g;
}

/**
 * @brief Adiciona um novo vértice ao grafo.
 * @param g Ponteiro para o grafo.
 * @param freq Caractere representando a frequência da antena.
 * @param x Coordenada X da antena.
 * @param y Coordenada Y da antena.
 * @return Ponteiro para o novo vértice criado.
 */
Vertice* adicionarVertice(Grafo *g, char freq, int x, int y) {
    Vertice *novo = malloc(sizeof(Vertice));
    novo->frequencia = freq;
    novo->x = x;
    novo->y = y;
    novo->arestas = NULL;
    novo->prox = g->vertices;
    g->vertices = novo;
    return novo;
}

/**
 * @brief Adiciona uma aresta entre dois vértices.
 * @param v1 Vértice de origem.
 * @param v2 Vértice de destino.
 */
void adicionarAresta(Vertice *v1, Vertice *v2) {
    Aresta *a = malloc(sizeof(Aresta));
    a->destino = v2;
    a->prox = v1->arestas;
    v1->arestas = a;
}

/**
 * @brief Constrói um grafo a partir de um ficheiro de texto.
 * @param g Ponteiro para o grafo.
 * @param nomeFicheiro Nome do ficheiro a ser lido.
 * @return 1 em caso de sucesso, 0 em caso de falha.
 */
int construirGrafoDeFicheiro(Grafo *g, const char *nomeFicheiro) {
    FILE *f = fopen(nomeFicheiro, "r");
    if (!f) return 0;

    char linha[100];
    int y = 0;
    Vertice *todos[500];
    int count = 0;

    while (fgets(linha, sizeof(linha), f)) {
        linha[strcspn(linha, "\n")] = 0;
        int col = strlen(linha);
        for (int x = 0; x < col; x++) {
            if (linha[x] != '.') {
                todos[count++] = adicionarVertice(g, linha[x], x, y);
            }
        }
        y++;
    }
    fclose(f);

    for (int i = 0; i < count; i++) {
        for (int j = i + 1; j < count; j++) {
            if (todos[i]->frequencia == todos[j]->frequencia) {
                adicionarAresta(todos[i], todos[j]);
                adicionarAresta(todos[j], todos[i]);
            }
        }
    }
    return 1;
}

/**
 * @brief Guarda os vértices do grafo num ficheiro binário.
 * @param g Ponteiro para o grafo.
 * @param ficheiro Nome do ficheiro binário.
 * @return 1 em caso de sucesso, 0 em caso de falha.
 */
int guardarGrafoBinario(Grafo *g, const char *ficheiro) {
    FILE *f = fopen(ficheiro, "wb");
    if (!f) return 0;
    for (Vertice *v = g->vertices; v; v = v->prox) {
        fwrite(&v->frequencia, sizeof(char), 1, f);
        fwrite(&v->x, sizeof(int), 1, f);
        fwrite(&v->y, sizeof(int), 1, f);
    }
    fclose(f);
    return 1;
}

/**
 * @brief Carrega os vértices de um grafo a partir de um ficheiro binário.
 * @param g Ponteiro para o grafo.
 * @param ficheiro Nome do ficheiro binário.
 * @return 1 em caso de sucesso, 0 em caso de falha.
 */
int carregarGrafoBinario(Grafo *g, const char *ficheiro) {
    FILE *f = fopen(ficheiro, "rb");
    if (!f) return 0;

    char freq;
    int x, y;
    while (fread(&freq, sizeof(char), 1, f) &&
           fread(&x, sizeof(int), 1, f) &&
           fread(&y, sizeof(int), 1, f)) {
        adicionarVertice(g, freq, x, y);
    }
    fclose(f);
    return 1;
}

/**
 * @brief Liga todos os vértices com a mesma frequência.
 * @param g Ponteiro para o grafo.
 */
void conectarVerticesMesmaFrequencia(Grafo *g) {
    for (Vertice *v1 = g->vertices; v1; v1 = v1->prox) {
        for (Vertice *v2 = v1->prox; v2; v2 = v2->prox) {
            if (v1->frequencia == v2->frequencia) {
                adicionarAresta(v1, v2);
                adicionarAresta(v2, v1);
            }
        }
    }
}

/**
 * @brief Lista todas as antenas presentes no grafo.
 * @param g Ponteiro para o grafo.
 */
void listarVertices(Grafo *g) {
    printf("Antenas no grafo:\n");
    for (Vertice *v = g->vertices; v; v = v->prox)
        printf("Frequência %c em (%d, %d)\n", v->frequencia, v->x, v->y);
}

/**
 * @brief Função auxiliar recursiva para DFS.
 * @param v Vértice atual.
 * @param visitado Matriz de vértices visitados.
 */
void dfs_rec(Vertice *v, int visitado[100][100]) {
    if (visitado[v->x][v->y]) return;
    visitado[v->x][v->y] = 1;
    printf("(%d, %d)\n", v->x, v->y);
    for (Aresta *a = v->arestas; a; a = a->prox)
        dfs_rec(a->destino, visitado);
}

/**
 * @brief Executa a procura em profundidade (DFS) a partir de um vértice.
 * @param inicio Vértice de partida.
 */
void dfs(Vertice *inicio) {
    int visitado[100][100] = {{0}};
    printf("DFS:\n");
    dfs_rec(inicio, visitado);
}

/**
 * @brief Função auxiliar recursiva que imprime todos os caminhos entre dois vértices.
 * @param atual Vértice atual.
 * @param fim Vértice de destino.
 * @param visitado Matriz de vértices visitados.
 * @param caminho Buffer de caminho atual.
 * @param nivel Nível atual do caminho.
 */
void caminhosEntreRec(Vertice *atual, Vertice *fim, int visitado[100][100], char *caminho, int nivel) {
    if (atual == fim) {
        caminho[nivel] = '\0';
        printf("%s(%d,%d)\n", caminho, fim->x, fim->y);
        return;
    }

    visitado[atual->x][atual->y] = 1;
    int len = sprintf(&caminho[nivel], "(%d,%d)->", atual->x, atual->y);
    nivel += len;

    for (Aresta *a = atual->arestas; a; a = a->prox) {
        if (!visitado[a->destino->x][a->destino->y])
            caminhosEntreRec(a->destino, fim, visitado, caminho, nivel);
    }

    visitado[atual->x][atual->y] = 0;
}

/**
 * @brief Imprime todos os caminhos possíveis entre dois vértices.
 * @param inicio Vértice inicial.
 * @param fim Vértice final.
 */
void caminhosEntre(Vertice *inicio, Vertice *fim) {
    char caminho[1000];
    int visitado[100][100] = {{0}};
    printf("Caminhos entre (%d,%d) e (%d,%d):\n", inicio->x, inicio->y, fim->x, fim->y);
    caminhosEntreRec(inicio, fim, visitado, caminho, 0);
}

/**
 * @brief Verifica e imprime interseções entre duas frequências distintas nas mesmas coordenadas.
 * @param g Ponteiro para o grafo.
 * @param f1 Primeira frequência.
 * @param f2 Segunda frequência.
 */
void intersecoesFrequencias(Grafo *g, char f1, char f2) {
    printf("Interseções entre frequências %c e %c:\n", f1, f2);
    for (Vertice *v1 = g->vertices; v1; v1 = v1->prox) {
        if (v1->frequencia != f1) continue;
        for (Vertice *v2 = g->vertices; v2; v2 = v2->prox) {
            if (v2->frequencia == f2 &&
                v1->x == v2->x && v1->y == v2->y) {
                printf("Interseção em (%d, %d)\n", v1->x, v1->y);
            }
        }
    }
}
